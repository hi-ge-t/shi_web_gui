import React, { useState } from "react";
import Gamepad from "react-gamepad";
import ROSLIB from "roslib";

const GamepadControl = () => {
  const [stick, setStick] = useState({ x: 0, y: 0 });

  // ROS2 WebSocketの接続
  const ros = new ROSLIB.Ros({ url: "ws://localhost:9090" });

  // 速度コマンドのトピック
  const cmdVel = new ROSLIB.Topic({
    ros: ros,
    name: "/cmd_vel",
    messageType: "geometry_msgs/Twist"
  });

  // ジョイスティックの移動時に速度を送信
  const handleMove = (x, y) => {
    setStick({ x, y });

    const twist = new ROSLIB.Message({
      linear: { x: y, y: 0, z: 0 },  // 前後の移動はY軸
      angular: { x: 0, y: 0, z: -x } // 左右の旋回はX軸
    });

    cmdVel.publish(twist);
  };

  return (
    <Gamepad onMove={(x, y) => handleMove(x, y)}>
      <div>
        <h2>ジョイスティック操作</h2>
        <p>前後: {stick.y.toFixed(2)} | 左右: {stick.x.toFixed(2)}</p>
      </div>
    </Gamepad>
  );
};

export default GamepadControl;
