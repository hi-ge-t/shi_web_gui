import React, { useState } from "react";

const CameraFeed = () => {
  // モック画像のリスト（仮に6台のカメラ）
  const cameraSources = [
    "https://fakeimg.pl/640x480?text=Camera1",
    "https://fakeimg.pl/640x480?text=Camera2",
    "https://fakeimg.pl/640x480?text=Camera3",
    "https://fakeimg.pl/640x480?text=Camera4",
    "https://fakeimg.pl/640x480?text=Camera5",
    "https://fakeimg.pl/640x480?text=Camera6"
  ];

  // メインカメラ（初期状態はCamera1）
  const [mainCamera, setMainCamera] = useState(cameraSources[0]);

  return (
    <div style={{ textAlign: "center" }}>
      {/* メインカメラ表示 */}
      <h2>メインカメラ</h2>
      <img src={mainCamera} alt="Main Camera" width="640" height="480" />

      {/* カメラ切り替えボタン */}
      <h3>他のカメラ</h3>
      <div style={{ display: "flex", justifyContent: "center" }}>
        {cameraSources.map((src, index) => (
          <img
            key={index}
            src={src}
            alt={`Camera ${index + 1}`}
            width="120"
            height="90"
            style={{ margin: "5px", cursor: "pointer", border: mainCamera === src ? "2px solid red" : "1px solid gray" }}
            onClick={() => setMainCamera(src)}
          />
        ))}
      </div>
    </div>
  );
};

export default CameraFeed;
