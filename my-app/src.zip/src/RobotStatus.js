import React, { useEffect, useState } from "react";
import ROSLIB from "roslib";
import "./RobotStatus.css";

const RobotStatus = () => {
  const [battery, setBattery] = useState(100);
  const [temperature, setTemperature] = useState(30);
  const [network, setNetwork] = useState("Connected");

  useEffect(() => {
    const ros = new ROSLIB.Ros({ url: "ws://localhost:9090" });

    ros.on("connection", () => setNetwork("Connected"));
    ros.on("error", () => setNetwork("Disconnected"));

    // バッテリーや温度の情報をROSトピックから取得（仮）
    const batteryListener = new ROSLIB.Topic({
      ros: ros,
      name: "/battery",
      messageType: "std_msgs/Float32"
    });

    batteryListener.subscribe((message) => {
      setBattery(message.data);
    });

    const tempListener = new ROSLIB.Topic({
      ros: ros,
      name: "/temperature",
      messageType: "std_msgs/Float32"
    });

    tempListener.subscribe((message) => {
      setTemperature(message.data);
    });

    return () => {
      batteryListener.unsubscribe();
      tempListener.unsubscribe();
      ros.close();
    };
  }, []);

  return (
    <div className="robot-status-container">
      <h2 className="robot-status-text">Robot Status</h2>
      <p className="robot-status-detail">Battery: 🔋 {battery}%</p>
      <p className="robot-status-detail">Temperature: 🌡️ {temperature}°C</p>
      <p className="robot-status-detail">Network: 📡 {network}</p>
    </div>
  );
};

export default RobotStatus;
