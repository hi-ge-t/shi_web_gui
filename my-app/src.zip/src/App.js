import React from "react";
import RobotControl from "./RobotControl";
import Settings from "./Settings";
import ThemeToggle from "./ThemeToggle";
import "./global.css";

function App() {
  return (
    <div className="app-container">
      <div className="top-right-buttons">
        <Settings />
        <ThemeToggle />
      </div>
      <RobotControl />
    </div>
  );
}

export default App;
