import React from "react";
import CameraView from "./CameraView";
import RobotStatus from "./RobotStatus";
import GamepadControl from "./GamepadControl";
import "./RobotControl.css";

const RobotControl = () => {
  return (
    <div className="robot-container">
      {/* タイトルと設定ボタン */}
      <div className="top-overlay">
        <h1 className="neon-title">SHI Robot Cntroller</h1>
      </div>

      {/* カメラエリア */}
      <div className="camera-wrapper">
        <CameraView />
      </div>

      {/* 右側のロボットのステータスとジョイスティック */}
      <div className="status-overlay">
        <RobotStatus />
        <GamepadControl />
      </div>
    </div>
  );
};

export default RobotControl;
