import React, { useState, useEffect } from "react";
import "./CameraView.css";

const cameraSources = [
  "https://fakeimg.pl/600x400/00feba,128/ffffff?text=Camera1",
  "https://fakeimg.pl/600x400/00aaff,128/ffffff?text=Camera2",
  "https://fakeimg.pl/600x400/0088ff,128/ffffff?text=Camera3",
  "https://fakeimg.pl/600x400/0066ff,128/ffffff?text=Camera4",
  "https://fakeimg.pl/600x400/0044ff,128/ffffff?text=Camera5",
  "https://fakeimg.pl/600x400/0022ff,128/ffffff?text=Camera6"
];

const CameraView = () => {
  const [selectedCamera, setSelectedCamera] = useState(0);

  useEffect(() => {
    // カメラ切り替え時にエフェクトを削除
  }, [selectedCamera]);

  return (
    <div className="camera-container">
      <div className="camera-preview">
        <h2>📷 Camera View</h2>
        <img src={cameraSources[selectedCamera]} alt={`Camera ${selectedCamera + 1}`} />
      </div>

      <div className="camera-thumbnails">
        {cameraSources.map((src, index) => (
          <img
            key={index}
            className={`thumbnail ${selectedCamera === index ? "active" : ""}`}
            src={src}
            alt={`Camera ${index + 1}`}
            onClick={() => setSelectedCamera(index)}
          />
        ))}
      </div>
    </div>
  );
};

export default CameraView;
